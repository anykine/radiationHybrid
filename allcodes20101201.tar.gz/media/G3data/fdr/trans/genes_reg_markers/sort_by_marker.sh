sort -k2n -k1n -S2000000M -T /media ../g3alpha_model_results1_gt2.4trans.txt > trans2.4bymarker.txt
