#!/usr/bin/perl -w
#
use strict;

unless (@ARGV==2){
	print <<EOH
	$0 <mouse file> <human file>
EOH
exit(1);
}

#read common genes across mouse/human arrays



#
