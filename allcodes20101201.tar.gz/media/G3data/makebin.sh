#!/bin/bash
#/home/rwang/tut/bin/g3conv -b /home3/rwang/QTL_comp/output1/g3alpha_model_results1.txt g3alpha_model_results1
