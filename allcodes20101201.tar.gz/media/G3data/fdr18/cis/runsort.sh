sort -g --buffer-size=200M --temporary-directory=/media/G3data hg18cis.txt > hg18cis_sorted.txt
