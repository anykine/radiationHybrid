liftOver.linux.x86_64 -minMatch=0.1 ../RNAFAR.bed /drive2/liftover/mm9ToHg18.over.chain RNAFAR_hg18.bed RNAFAR_hg18.unmapped
