#!/bin/bash
./run_fold.pl 1 50 & ./run_fold.pl 101 150
