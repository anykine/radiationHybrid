#!/bin/bash

./run_check_blast_res.pl 1 150 2>blastparse1.log & ./run_check_blast_res.pl 151 450  2>blastparse2.log
