#!/bin/bash
./run_extract_frags.pl 1 50 
