#!/bin/bash
./run_fold.pl 431 440 & ./run_fold.pl 441 450
