#!/bin/bash
./find_max_hairpin.pl 1 50 & ./find_max_hairpin.pl 101 150
./find_max_hairpin.pl 431 450 
