wc -l trans_allp_sorted.txt > rw_num.txt
wc -l trans_allp_fdr.txt  >> rw_num.txt
