./nearestZG3 ../../chrom_size_36.txt \
/media/G3data/fdr18/trans/zero_gene_peaks/NEW/unique/mouse2humblocks/fdr30/human_fdr30_labelled.txt \
/media/G3data/fdr18/trans/zero_gene_peaks/NEW/unique/mouse2humblocks/fdr30/m2h_fdr30_labelled.txt \
1200 800

