./nearestZGplot2 ../../chrom_size_36.txt \
/media/G3data/fdr18/trans/zero_gene_peaks/NEW/unique/peaks3/zero_gene_peaks3_FDR30_ranges300k.txt \
mus2hum_zerogene_block_pos_fdr30_err.txt \
1200 800

