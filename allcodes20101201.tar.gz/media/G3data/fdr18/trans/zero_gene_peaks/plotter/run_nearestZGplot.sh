./nearestZGplot chrom_size_36.txt ../NEW/unique/zero_gene_peaks_uniq_nearest.txt 1200 800
