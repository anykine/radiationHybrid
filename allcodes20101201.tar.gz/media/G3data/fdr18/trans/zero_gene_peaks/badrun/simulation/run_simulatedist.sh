#!/bin/bash
./simulate.pl 10000 > simbydist10k.txt
./simulate.pl 5000 > simbydist5k.txt
./simulate.pl 8000 > simbydist8k.txt
./simulate.pl 15000 > simbydist15k.txt
