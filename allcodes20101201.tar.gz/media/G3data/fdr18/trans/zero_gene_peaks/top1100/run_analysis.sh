R --vanilla < analysis.R > test.out
