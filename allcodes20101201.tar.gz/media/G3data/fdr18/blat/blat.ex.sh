blat -stepSize=5 -repMatch=2253 -minScore=0 -minIdentity=0 -q=dna -t=dna /drive2/mm7/chr7.fa test2.fa test2.psl
