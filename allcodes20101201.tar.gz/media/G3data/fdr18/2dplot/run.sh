#!/bin/bash
/home/rwang/tut/plotlarge/hyun/plotlarged genepos.txt markerpos.txt hg18chrsize.txt pvalsc.txt 1200 1200 1 2.4 15 > output1.png
