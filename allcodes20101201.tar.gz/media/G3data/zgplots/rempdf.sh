!#/bin/bash

for i in *.pdf
do
	#echo $i
	rm ${i}
done
