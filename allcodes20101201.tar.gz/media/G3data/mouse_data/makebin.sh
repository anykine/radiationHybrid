./t31dataconv -b alp_grid_scaled.txt alp_grid_scaled
./t31dataconv -b nlp_perm_grid.txt nlp_perm_grid
