#spots 1,2,4,6,9,10
#../../apps/get_marker_region.pl  ../11084_vec_inorder.txt.out.pval 1376 1508 1402 1535 >mousespot-1.txt 
#../../apps/get_marker_region.pl  ../11084_vec_inorder.txt.out.pval 3801 4495 3825 4522 >mousespot-2.txt 
../../apps/get_marker_region.pl  ../11084_vec_inorder.txt.out.pval 4410 6008 4233 6040 >mousespot-4.txt
../../apps/get_marker_region.pl  ../11084_vec_inorder.txt.out.pval 4165 8354 4195 8380 >mousespot-6.txt
../../apps/get_marker_region.pl  ../11084_vec_inorder.txt.out.pval 1169 5150 1205 5173 >mousespot-9.txt
../../apps/get_marker_region.pl  ../11084_vec_inorder.txt.out.pval 1154 4229 1297 4258 >mousespot-10.txt
echo "done"
