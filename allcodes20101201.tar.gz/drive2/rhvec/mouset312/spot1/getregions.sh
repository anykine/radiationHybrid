#spots 3, 5, 7, 8
../../apps/get_marker_region.pl  ../11084_vec_inorder.txt.out.pval 3910 4170 3975 4227 >mousespot-1.txt 
../../apps/get_marker_region.pl  ../11084_vec_inorder.txt.out.pval 7969 8960 8025 9026 >mousespot-2.txt 
../../apps/get_marker_region.pl  ../11084_vec_inorder.txt.out.pval 291 9074 319 9109 >mousespot-3.txt 
../../apps/get_marker_region.pl  ../11084_vec_inorder.txt.out.pval 134 8169 189 8221 >mousespot-4.txt 
echo "done"
